import { useEffect, useMemo, useState } from 'react'
import { MotionConfig, motion } from 'framer-motion'
import {
  fadeFromX,
  staggerContainer,
  viewportOnce,
} from '../components/home/homeMotion'
import { SiteHeader } from '../components/SiteHeader'
import { PartnershipFooter } from '../components/PartnershipFooter'
import { PageContent } from '../components/PageContent'
import { CaseStudyAetherSection } from '../components/CaseStudyAetherSection'
import { CaseStudyFeaturedSection } from '../components/case-studies/CaseStudyFeaturedSection'
import { CaseStudiesVoidCta } from '../components/case-studies/CaseStudiesVoidCta'
import { getCaseStudies } from '../lib/strapi'

export default function CaseStudiesPage() {
  const [caseStudies, setCaseStudies] = useState([])
  const [caseState, setCaseState] = useState({ loading: false, error: '' })

  useEffect(() => {
    let mounted = true
    async function loadCaseStudies() {
      setCaseState({ loading: true, error: '' })
      try {
        const data = await getCaseStudies()
        if (!mounted || !Array.isArray(data) || data.length === 0) return
        setCaseStudies(data)
      } catch (error) {
        if (mounted) setCaseState({ loading: false, error: error.message || 'Failed to load case studies.' })
        return
      }
      if (mounted) setCaseState({ loading: false, error: '' })
    }
    loadCaseStudies()
    return () => {
      mounted = false
    }
  }, [])

  const firstCaseStudy = useMemo(() => caseStudies[0] || null, [caseStudies])
  const secondCaseStudy = useMemo(() => caseStudies[1] || null, [caseStudies])

  return (
    <>
      <main className="mx-auto w-full max-w-[1280px] bg-[#0E0E0E] text-white">
        <SiteHeader />

        <MotionConfig reducedMotion="user">
          <PageContent>
            <section className="w-full max-w-[1280px]">
              <motion.div
                className="mx-auto w-full max-w-[1216px]"
                variants={staggerContainer(0.08, 0.14)}
                initial="hidden"
                animate="visible"
              >
                <div className="flex flex-col gap-[24px]">
                  <motion.p
                    variants={fadeFromX(-14)}
                    className="text-left font-semibold uppercase text-[#AFA2FF]"
                    style={{ fontSize: '16px', lineHeight: '1.5em', letterSpacing: '0.2em', fontWeight: 600 }}
                  >
                    Real outcomes from partne
                  </motion.p>
                  <motion.h1
                    variants={fadeFromX(-18)}
                    className="whitespace-pre-line text-left text-[56px] font-bold leading-[1em] tracking-[-0.05em] text-white sm:text-[72px] lg:text-[96px]"
                  >
                    {`Engineering\nPrecision for the AI\nFrontier.`}
                  </motion.h1>
                  <motion.div variants={fadeFromX(-16)} className="max-w-[672px] pt-[8px]">
                    <p className="text-left text-[24px] font-normal leading-[1.3333333333333333em] text-[#ABABAB]">
                      We don&apos;t just build software. We engineer high-stakes AI infrastructure
                      and products that deliver measurable competitive advantages.
                    </p>
                  </motion.div>
                </div>
              </motion.div>
            </section>

            <section className="w-full max-w-[1280px]">
              <motion.div
                className="mx-auto flex w-full max-w-[1216px] flex-col gap-[64px]"
                variants={staggerContainer(0.1, 0.14)}
                initial="hidden"
                whileInView="visible"
                viewport={viewportOnce}
              >
                <motion.h2
                  variants={fadeFromX(-18)}
                  className="text-left text-white"
                  style={{ fontSize: '36px', lineHeight: '1.1111111111111112em', fontWeight: 700, letterSpacing: '-0.025em' }}
                >
                  Success Stories
                </motion.h2>
                <CaseStudyAetherSection entry={firstCaseStudy} />
                <CaseStudyFeaturedSection entry={secondCaseStudy} />
              </motion.div>
            </section>

            <CaseStudiesVoidCta />

            <section className="relative w-full max-w-[1280px] overflow-hidden">
            <div
              className="pointer-events-none absolute inset-0 opacity-[0.03]"
              style={{
                background: 'linear-gradient(150deg, rgba(116, 89, 247, 1) 0%, rgba(175, 162, 255, 1) 100%)',
              }}
              aria-hidden
            />
            {/* <div className="relative mx-auto flex w-full max-w-[1280px] flex-col items-center gap-[32px] py-[64px] sm:py-[96px] lg:px-[192px] lg:py-[160px]">
              <h2 className="max-w-[758px] whitespace-pre-line text-center text-[40px] font-bold leading-[1em] tracking-[-0.025em] text-white sm:text-[56px] lg:text-[72px]">
                {`Build Your Engineering\nTeam Without Hiring\nStress.`}
              </h2>
              <div className="pb-[16px]">
                <p className="max-w-[882px] text-center text-[20px] font-normal leading-[1.4em] text-[#ABABAB]">
                  Stop the endless search for senior talent. Access a battle-tested studio that delivers from day one.
                </p>
              </div>
              <Link
                to="/contact"
                className="rounded-[6px] text-center text-[20px] font-bold leading-[1.4em]"
                style={{
                  padding: '20px 48px',
                  background: 'linear-gradient(168deg, rgba(116, 89, 247, 1) 0%, rgba(175, 162, 255, 1) 100%)',
                  color: '#000000',
                }}
              >
                Start Your Project Now
              </Link>
            </div> */}
            </section>
            {caseState.loading ? <p className="text-center text-sm text-[#ABABAB]">Loading case studies...</p> : null}
            {caseState.error ? <p className="text-center text-sm text-[#ff8c8c]">Using fallback case studies: {caseState.error}</p> : null}
          </PageContent>
        </MotionConfig>

        <PartnershipFooter />
      </main>
    </>
  )
}
