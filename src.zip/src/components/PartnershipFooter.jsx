import { Link } from 'react-router-dom'

export function PartnershipFooter() {
  return (
    <footer className="bg-[#131313]">
      <div className="mx-auto w-full max-w-[1280px] px-4 pb-10 pt-16 sm:px-8 sm:pt-20">
        <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8">
          <div className="border-b border-[rgba(255,255,255,0.05)] pb-6 lg:border-0 lg:pb-0">
            <Link to="/" className="text-[20px] font-bold leading-[1.4] tracking-[0.0175em] text-white hover:text-[#AFA2FF]">
              JVO Labs
            </Link>
            <p className="mt-[15px] max-w-[280px] text-[14px] leading-[1.625] tracking-[0.025em] text-[#ABABAB]">
              Precision engineering for the AI era. Building the foundations of next-gen digital infrastructure.
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase leading-[2em] tracking-[0.1em] text-white">Ecosystem</p>
            <ul className="mt-4 space-y-4 text-[14px] leading-[1.43] tracking-[0.025em] text-[#ABABAB]">
              <li>
                <a href="#" className="hover:text-white">
                  Build Your Engineering Team
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  AI Infrastructure
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Product Strategy
                </a>
              </li>
            </ul>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase leading-[2em] tracking-[0.1em] text-white">Company</p>
            <ul className="mt-4 space-y-4 text-[14px] leading-[1.43] tracking-[0.025em] text-[#ABABAB]">
              <li>
                <Link to="/contact" className="hover:text-white">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/about-us" className="hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Careers
                </a>
              </li>
            </ul>
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase leading-[2em] tracking-[0.1em] text-white">Legal</p>
            <ul className="mt-4 space-y-4 text-[14px] leading-[1.43] tracking-[0.025em] text-[#ABABAB]">
              <li>
                <a href="#" className="hover:text-white">
                  Privacy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white">
                  Terms
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-6 border-t border-[rgba(255,255,255,0.05)] pt-8 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[16px] leading-[1.5] text-[#ABABAB]">© 2024 JVO Labs. Precision Engineering for the AI Era.</p>
          <div className="flex items-center gap-6 text-[#ABABAB]">
            <a href="#" className="hover:text-white" aria-label="LinkedIn">
              <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden>
                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
              </svg>
            </a>
            <a href="#" className="hover:text-white" aria-label="X">
              <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden>
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
              </svg>
            </a>
            <a href="#" className="hover:text-white" aria-label="GitHub">
              <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden>
                <path
                  fillRule="evenodd"
                  d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
                  clipRule="evenodd"
                />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
