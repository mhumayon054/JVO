import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { useCallback, useEffect, useState } from 'react'
import saburMortazawiImage from '../assets/testimonials/sabur-mortazawi.jpg'

const TESTIMONIALS = [
  {
    quote:
      "Faizan and his team don't just execute; they think along with you, understand your goals, and deliver smart solutions with flexibility.",
    fullQuote: `Faizan and his team have been a pleasure to work with. They don't just execute, they think along with you, truly understand your goals, and come up with smart solutions on their own initiative. What stands out most is their flexibility and reliability; no matter how tight the deadline or how often priorities shifted, they consistently delivered on time and at a high standard. Communication is smooth, feedback is taken seriously, and you always feel like you're working with people who genuinely care about the end result. I'd highly recommend Faizan to anyone looking for a dependable, solution-oriented team.`,
    name: 'Sabur Mortazawi',
    role: 'CEO bij Taxionspot',
    metric: 'Client recommendation',
    image: saburMortazawiImage,
  },
  {
    quote:
      'Very professional team they always keep their word, think in solutions, and avoid the usual excuses or extra charges. 10 out of 10.',
    fullQuote: `Very profesional team always keeping their word thinking slutions instead of we can not do that or extra money 10 out of 10.`,
    name: 'Luis Bennett',
    role: 'WordPress cancellation service MVP',
    metric: '5.0 review · Jan 15 – Feb 22, 2026',
    image: null,
  },
  {
    quote:
      'Their biggest strength is not just writing code. They think through architecture, scale, and product risk before building.',
    name: 'Elena Brooks',
    role: 'CEO, SignalForge',
    metric: 'Architecture-first delivery',
  },
]

const EASE = [0.22, 1, 0.36, 1]
const DRAG_THRESHOLD = 55
const VELOCITY_THRESHOLD = 450

function TestimonialAvatar({ testimonial, size = 'sm' }) {
  const sizeClass = size === 'md' ? 'h-12 w-12' : 'h-11 w-11'

  if (testimonial.image) {
    return (
      <img
        src={testimonial.image}
        alt={testimonial.name}
        loading="lazy"
        className={`${sizeClass} shrink-0 rounded-[14px] border border-[rgba(175,162,255,0.22)] object-cover shadow-[0_10px_28px_rgba(0,0,0,0.35)]`}
      />
    )
  }

  return (
    <div
      className={`${sizeClass} flex shrink-0 items-center justify-center rounded-[14px] border border-[rgba(175,162,255,0.22)] bg-[linear-gradient(135deg,rgba(116,89,247,0.22),rgba(175,162,255,0.08))] text-[#CFC7FF] shadow-[0_10px_28px_rgba(0,0,0,0.35)]`}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-5 w-5"
        aria-hidden="true"
      >
        <path d="M20 21a8 8 0 0 0-16 0" />
        <circle cx="12" cy="8" r="4" />
      </svg>
    </div>
  )
}

export function TestimonialsFloatingWidget() {
  function getInitialWidgetState() {
    if (typeof window === 'undefined') return true
    return window.matchMedia('(min-width: 768px)').matches
  }

  const [isOpen, setIsOpen] = useState(getInitialWidgetState)
  const [[activeIndex, direction], setSlide] = useState([0, 1])
  const [isHovered, setIsHovered] = useState(false)
  const [selectedFullReview, setSelectedFullReview] = useState(null)
  const shouldReduceMotion = useReducedMotion()

  const paginate = useCallback((nextDirection) => {
    setSlide(([currentIndex]) => {
      const nextIndex =
        (currentIndex + nextDirection + TESTIMONIALS.length) % TESTIMONIALS.length

      return [nextIndex, nextDirection]
    })
  }, [])

  const goToIndex = useCallback((nextIndex) => {
    setSlide(([currentIndex]) => {
      if (nextIndex === currentIndex) return [currentIndex, 0]

      return [nextIndex, nextIndex > currentIndex ? 1 : -1]
    })
  }, [])

  useEffect(() => {
    if (!isOpen || isHovered || selectedFullReview) return undefined

    const timer = window.setInterval(() => {
      paginate(1)
    }, 10000)

    return () => window.clearInterval(timer)
  }, [isOpen, isHovered, selectedFullReview, paginate])

  const handleDragEnd = (_, info) => {
    const swipeOffset = info.offset.x
    const swipeVelocity = info.velocity.x

    if (swipeOffset < -DRAG_THRESHOLD || swipeVelocity < -VELOCITY_THRESHOLD) {
      paginate(1)
      return
    }

    if (swipeOffset > DRAG_THRESHOLD || swipeVelocity > VELOCITY_THRESHOLD) {
      paginate(-1)
    }
  }

  const activeTestimonial = TESTIMONIALS[activeIndex]
  const modalTestimonial = selectedFullReview

  return (
    <div className="fixed bottom-7 right-4 z-[90] flex items-end justify-end sm:right-7">
      <AnimatePresence>
        {isOpen ? (
          <motion.aside
            key="testimonials-panel"
            aria-label="Client testimonials"
            initial={
              shouldReduceMotion
                ? { opacity: 0 }
                : {
                    opacity: 0,
                    scale: 0.82,
                    x: 48,
                    y: 72,
                    filter: 'blur(18px)',
                  }
            }
            animate={
              shouldReduceMotion
                ? { opacity: 1 }
                : {
                    opacity: 1,
                    scale: 1,
                    x: 0,
                    y: 0,
                    filter: 'blur(0px)',
                  }
            }
            exit={
              shouldReduceMotion
                ? { opacity: 0 }
                : {
                    opacity: 0,
                    scale: 0.18,
                    x: 208,
                    y: 136,
                    rotate: 2,
                    filter: 'blur(26px)',
                  }
            }
            transition={{ duration: shouldReduceMotion ? 0.2 : 0.55, ease: EASE }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            className="absolute bottom-[72px] right-0 h-auto max-h-[min(430px,calc(100vh-120px))] w-[calc(100vw-32px)] max-w-[640px] overflow-hidden rounded-[22px] border border-[rgba(72,72,72,0.18)] bg-[#0E0E0E]/85 p-3 shadow-[0_28px_90px_rgba(0,0,0,0.58),0_0_60px_rgba(116,89,247,0.16)] backdrop-blur-[22px] sm:bottom-[76px] sm:h-[285px] sm:p-5 md:w-[640px]"
          >
            <div
              className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-[#7459F7]/20 blur-[72px]"
              aria-hidden="true"
            />
            <div
              className="pointer-events-none absolute -bottom-24 left-10 h-44 w-44 rounded-full bg-[#AFA2FF]/10 blur-[80px]"
              aria-hidden="true"
            />
            <div
              className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_88%_86%,rgba(116,89,247,0.12),transparent_34%),linear-gradient(135deg,rgba(255,255,255,0.055),transparent_42%)]"
              aria-hidden="true"
            />

            <div className="relative flex h-full flex-col">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#AFA2FF]">
                    Client Signals
                  </p>
                  <h2 className="mt-1 text-[16px] font-bold leading-tight tracking-[-0.02em] text-white sm:text-[20px]">
                    Founder feedback from high-velocity builds.
                  </h2>
                </div>

                <button
                  type="button"
                  aria-label="Minimize testimonials"
                  onClick={() => setIsOpen(false)}
                  className="group inline-flex h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-full border border-[rgba(72,72,72,0.22)] bg-[#131313]/80 text-[#ABABAB] transition-[border-color,background-color,color,transform] duration-200 ease-out hover:border-[rgba(116,89,247,0.42)] hover:bg-[rgba(116,89,247,0.1)] hover:text-white active:scale-95 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7459F7]"
                >
                  <span className="block h-[2px] w-3 rounded-full bg-current" />
                </button>
              </div>

              <div className="relative mt-3 min-h-0 flex-1 overflow-hidden rounded-2xl border border-[rgba(72,72,72,0.15)] bg-[#131313]/70 p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.035)] sm:mt-4 sm:p-5">
                <AnimatePresence mode="wait" custom={direction}>
                  <motion.article
                    key={activeTestimonial.name}
                    custom={direction}
                    initial={
                      shouldReduceMotion
                        ? { opacity: 0 }
                        : {
                            opacity: 0,
                            x: direction >= 0 ? 38 : -38,
                            filter: 'blur(8px)',
                          }
                    }
                    animate={
                      shouldReduceMotion
                        ? { opacity: 1 }
                        : {
                            opacity: 1,
                            x: 0,
                            filter: 'blur(0px)',
                          }
                    }
                    exit={
                      shouldReduceMotion
                        ? { opacity: 0 }
                        : {
                            opacity: 0,
                            x: direction >= 0 ? -38 : 38,
                            filter: 'blur(8px)',
                          }
                    }
                    transition={{ duration: shouldReduceMotion ? 0.18 : 0.42, ease: EASE }}
                    drag={shouldReduceMotion ? false : 'x'}
                    dragConstraints={{ left: 0, right: 0 }}
                    dragElastic={0.16}
                    onDragEnd={handleDragEnd}
                    className="flex h-full cursor-grab select-none touch-pan-y flex-col justify-between active:cursor-grabbing"
                  >
                    <div className="min-h-0 overflow-visible">
                      <div className="mb-3 inline-flex rounded-full border border-[rgba(116,89,247,0.24)] bg-[rgba(116,89,247,0.1)] px-3 py-1 text-[11px] font-bold uppercase tracking-[0.1em] text-[#AFA2FF]">
                        {activeTestimonial.metric}
                      </div>

                      <p
                        className="max-w-[540px] overflow-hidden pb-1 text-[13px] leading-[1.65] text-[#E7E7E7] sm:text-[15px] sm:leading-[1.65]"
                        style={{
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                        }}
                      >
                        “{activeTestimonial.quote}”
                      </p>
                    </div>

                    <div className="mt-4 flex shrink-0 items-center justify-between gap-4">
                      <div className="flex min-w-0 items-center gap-3">
                        <div className="min-w-0">
                          <p className="truncate text-[14px] font-bold text-white">
                            {activeTestimonial.name}
                          </p>
                          <p className="mt-1 truncate text-[12px] leading-tight text-[#757575]">
                            {activeTestimonial.role}
                          </p>
                        </div>

                        <TestimonialAvatar testimonial={activeTestimonial} />
                      </div>

                      <div className="flex shrink-0 items-center gap-3">
                        {activeTestimonial.fullQuote ? (
                          <button
                            type="button"
                            onPointerDown={(event) => event.stopPropagation()}
                            onClick={(event) => {
                              event.preventDefault()
                              event.stopPropagation()
                              setSelectedFullReview(activeTestimonial)
                            }}
                            className="cursor-pointer whitespace-nowrap rounded-full border border-[rgba(175,162,255,0.24)] bg-[rgba(116,89,247,0.1)] px-3 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-[#AFA2FF] transition-colors duration-200 hover:border-[rgba(175,162,255,0.46)] hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7459F7]"
                          >
                            Full review
                          </button>
                        ) : null}

                        <div className="flex shrink-0 items-center gap-1.5" aria-label="Testimonials navigation">
                          {TESTIMONIALS.map((testimonial, index) => (
                            <button
                              key={testimonial.name}
                              type="button"
                              aria-label={`Show testimonial ${index + 1}`}
                              aria-current={activeIndex === index}
                              onPointerDown={(event) => event.stopPropagation()}
                              onClick={(event) => {
                                event.stopPropagation()
                                goToIndex(index)
                              }}
                              className={`h-2 cursor-pointer rounded-full transition-all duration-300 ease-out focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7459F7] ${
                                activeIndex === index
                                  ? 'w-6 bg-[#AFA2FF]'
                                  : 'w-2 bg-[#484848] hover:bg-[#7459F7]'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.article>
                </AnimatePresence>
              </div>
            </div>
          </motion.aside>
        ) : null}
      </AnimatePresence>

      <motion.button
        type="button"
        aria-label={isOpen ? 'Testimonials are open' : 'Open testimonials'}
        onClick={() => setIsOpen(true)}
        whileHover={{ y: -2, scale: 1.025 }}
        whileTap={{ scale: 0.96 }}
        transition={{ duration: 0.22, ease: EASE }}
        className="group relative inline-flex h-[56px] cursor-pointer items-center justify-center gap-2 overflow-hidden rounded-[999px] border border-[rgba(175,162,255,0.32)] bg-[#0E0E0E]/90 px-4 text-[#F4F1FF] shadow-[0_18px_44px_rgba(116,89,247,0.28)] backdrop-blur-xl transition-colors duration-300 hover:border-[rgba(175,162,255,0.56)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#AFA2FF] sm:min-w-[154px]"
      >
        <span
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(175,162,255,0.26),transparent_34%),linear-gradient(135deg,rgba(116,89,247,0.24),rgba(175,162,255,0.08))]"
          aria-hidden="true"
        />
        <span
          className="pointer-events-none absolute inset-[3px] rounded-[999px] border border-white/10"
          aria-hidden="true"
        />

        <span className="relative z-[1] inline-flex h-8 w-8 items-center justify-center rounded-full bg-[#AFA2FF]/15 text-[#AFA2FF] ring-1 ring-[#AFA2FF]/25">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.9"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-[18px] w-[18px]"
            aria-hidden="true"
          >
            <path d="M7.5 9.5h4.8" />
            <path d="M7.5 13h7.2" />
            <path d="M8.2 18.5 5 21v-4.1A7.6 7.6 0 0 1 3.2 12C3.2 7.6 7.15 4 12 4s8.8 3.6 8.8 8-3.95 8-8.8 8a9.8 9.8 0 0 1-3.8-.75Z" />
            <path d="M16.5 8.2h.01" />
          </svg>
        </span>

        <span className="relative z-[1] hidden text-[12px] font-bold uppercase tracking-[0.14em] text-[#F4F1FF] sm:inline">
          Reviews
        </span>

        {!isOpen ? (
          <>
            <span
              className="absolute -inset-2 -z-10 rounded-full bg-[#7459F7]/35 blur-xl motion-safe:animate-pulse"
              aria-hidden="true"
            />
            <span
              className="absolute right-3 top-3 h-2 w-2 rounded-full bg-[#AFA2FF] shadow-[0_0_12px_rgba(175,162,255,0.9)]"
              aria-hidden="true"
            />
          </>
        ) : null}
      </motion.button>

      <AnimatePresence>
        {modalTestimonial ? (
          <motion.div
            key="full-review-modal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22, ease: EASE }}
            className="fixed inset-0 z-[999] flex items-center justify-center bg-black/75 px-4 backdrop-blur-sm"
            onClick={() => setSelectedFullReview(null)}
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label="Full client review"
              initial={
                shouldReduceMotion
                  ? { opacity: 0 }
                  : { opacity: 0, scale: 0.94, y: 24, filter: 'blur(10px)' }
              }
              animate={
                shouldReduceMotion
                  ? { opacity: 1 }
                  : { opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }
              }
              exit={
                shouldReduceMotion
                  ? { opacity: 0 }
                  : { opacity: 0, scale: 0.94, y: 24, filter: 'blur(10px)' }
              }
              transition={{ duration: shouldReduceMotion ? 0.18 : 0.34, ease: EASE }}
              onClick={(event) => event.stopPropagation()}
              className="relative w-full max-w-[620px] overflow-hidden rounded-[24px] border border-[rgba(175,162,255,0.22)] bg-[#0E0E0E]/95 p-5 shadow-[0_30px_100px_rgba(0,0,0,0.75),0_0_70px_rgba(116,89,247,0.22)] backdrop-blur-2xl sm:p-7"
            >
              <div
                className="pointer-events-none absolute -right-20 -top-20 h-52 w-52 rounded-full bg-[#7459F7]/20 blur-[80px]"
                aria-hidden="true"
              />

              <button
                type="button"
                aria-label="Close full review"
                onClick={() => setSelectedFullReview(null)}
                className="absolute right-4 top-4 inline-flex h-9 w-9 cursor-pointer items-center justify-center rounded-full border border-[rgba(72,72,72,0.28)] bg-[#131313]/90 text-[#ABABAB] transition-colors duration-200 hover:border-[rgba(116,89,247,0.42)] hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7459F7]"
              >
                ×
              </button>

              <div className="relative pr-10">
                <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#AFA2FF]">
                  Full client review
                </p>

                <div className="mt-5 flex items-center gap-3">
                  <TestimonialAvatar testimonial={modalTestimonial} size="md" />

                  <div>
                    <h3 className="text-[17px] font-bold text-white">
                      {modalTestimonial.name}
                    </h3>
                    <p className="mt-1 text-[13px] text-[#8A8A8A]">
                      {modalTestimonial.role}
                    </p>
                  </div>
                </div>

                <p className="mt-5 max-h-[52vh] overflow-y-auto pr-2 text-[15px] leading-[1.75] text-[#E7E7E7] sm:text-[16px]">
                  “{modalTestimonial.fullQuote || modalTestimonial.quote}”
                </p>
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  )
}
